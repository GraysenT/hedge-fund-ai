import random
import json
import os
import subprocess

LINEAGE_PATH = "strategy_memory/strategy_lineage.json"
FALLBACK_SEEDS = ["gen_strat_seed_a", "gen_strat_seed_b"]
GENERATED = []
lineage_full = {}

def evaluate_strategy(strategy_id):
    sharpe = round(random.uniform(-1.5, 2.5), 2)
    if sharpe > 1.0:
        rating = "🟢 Good"
    elif sharpe > 0.3:
        rating = "🟡 Moderate"
    elif sharpe > -0.3:
        rating = "🟠 Weak"
    else:
        rating = "🔴 Poor"
    return sharpe, rating

def recursive_evolution():
    global lineage_full

    # Run helper modules as proper Python modules
    print("python3 -m meta.lineage_tracker")
    subprocess.call(["python3", "-m", "meta.lineage_tracker"])
    print("python3 -m meta.clan_tagger")
    subprocess.call(["python3", "-m", "meta.clan_tagger"])
    print("python3 -m meta.recombination_engine")
    subprocess.call(["python3", "-m", "meta.recombination_engine"])

    # Inject fallback root strategies
    print("⚠️ Injected two fallback root strategies:", ", ".join(FALLBACK_SEEDS))
    for seed in FALLBACK_SEEDS:
        lineage_full[seed] = {
            "parent": "root",
            "depth": 0,
            "sharpe": 0,
            "rating": "🟡 Unknown"
        }

    # Create recursive children
    for i in range(5):
        parent = random.choice(FALLBACK_SEEDS)
        child = f"gen_strat_r{i+1}"
        depth = lineage_full[parent]["depth"] + 1
        sharpe, rating = evaluate_strategy(child)

        lineage_full[child] = {
            "parent": parent,
            "depth": depth,
            "sharpe": sharpe,
            "rating": rating
        }
        GENERATED.append((child, parent, depth, rating, sharpe))

    print(f"✅ Generated {len(GENERATED)} recursive strategies from survivors.")
    for c, p, d, r, s in GENERATED:
        print(f" - {c} ← {p} | Depth: {d} | Rating: {r} | Sharpe: {s}")

    with open(LINEAGE_PATH, "w") as f:
        json.dump(lineage_full, f, indent=2)
    print(f"✅ Strategy lineage saved to {LINEAGE_PATH}")

if __name__ == "__main__":
    recursive_evolution()
    
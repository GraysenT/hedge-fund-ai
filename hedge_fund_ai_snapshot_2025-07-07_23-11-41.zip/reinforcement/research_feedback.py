import pandas as pd
import os
from collections import defaultdict

def run(min_return_threshold=1.0):
    print("\n🔁 Research Feedback Engine Running...")

    sim_path = "logs/research_simulations.csv"
    out_path = "logs/research_feedback_scores.csv"

    if not os.path.exists(sim_path):
        print("❌ No research simulations found.")
        return

    df = pd.read_csv(sim_path)
    if df.empty:
        print("ℹ️ No simulations to process.")
        return

    # Use only passing simulations with good returns
    passing = df[(df["Passed"] == True) & (df["Simulated Return (%)"] >= min_return_threshold)]

    if passing.empty:
        print("ℹ️ No successful simulated ideas yet.")
        return

    score_map = defaultdict(float)

    for _, row in passing.iterrows():
        key = row["Strategy"]
        score_map[key] += row["Simulated Return (%)"]

    scores_df = pd.DataFrame.from_dict(score_map, orient="index", columns=["Research Boost Score"])
    scores_df.index.name = "Strategy"
    scores_df = scores_df.reset_index().sort_values("Research Boost Score", ascending=False)

    scores_df.to_csv(out_path, index=False)
    print(f"✅ Research feedback scores saved to: {out_path}")

if __name__ == "__main__":
    run()
    
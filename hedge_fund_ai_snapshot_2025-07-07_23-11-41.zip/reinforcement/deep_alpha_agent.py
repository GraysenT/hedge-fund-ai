import pandas as pd
from pathlib import Path
import numpy as np

PERF_PATH = Path("performance_logs")

def train_alpha_agent():
    df = pd.concat([pd.read_csv(f) for f in PERF_PATH.glob("performance_*.csv")])
    df["reward"] = df["pnl"]
    df["strategy_score"] = df.groupby("strategy")["reward"].rolling(5).mean().reset_index(level=0, drop=True)
    
    updated = df.groupby("strategy")["strategy_score"].mean().to_dict()
    path = Path("memory/deep_alpha_weights.csv")
    pd.DataFrame(list(updated.items()), columns=["strategy", "alpha_score"]).to_csv(path, index=False)
    print(f"🧠 Alpha agent updated scores: {path}")
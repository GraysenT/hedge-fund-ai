import pandas as pd
from pathlib import Path
from datetime import datetime
from reinforcement.failure_classifier import load_failure_data
from reinforcement.pattern_memory import load_pattern_memory

LABEL_PATH = Path("memory/self_labels")
LABEL_PATH.mkdir(parents=True, exist_ok=True)

def label_success_patterns(signals_df):
    """
    Label successful patterns based on past signals and outcomes.
    """
    labels = []

    for _, row in signals_df.iterrows():
        label = {
            "date": row["date"],
            "strategy": row["strategy"],
            "ticker": row["ticker"],
            "confidence": row["confidence"],
            "signal": row["signal"],
            "outcome": "success" if row["pnl"] > 0 else "fail"
        }
        labels.append(label)

    df = pd.DataFrame(labels)
    today = datetime.utcnow().strftime("%Y-%m-%d")
    df.to_csv(LABEL_PATH / f"self_labels_{today}.csv", index=False)
    print(f"📌 Saved self-labels to memory: {LABEL_PATH}/self_labels_{today}.csv")


def load_all_labels():
    files = list(LABEL_PATH.glob("self_labels_*.csv"))
    if not files:
        return pd.DataFrame()
    dfs = [pd.read_csv(f) for f in files]
    return pd.concat(dfs, ignore_index=True)


def score_strategies_from_labels():
    df = load_all_labels()
    if df.empty:
        return {}

    score = {}
    grouped = df.groupby("strategy")
    for strat, sub in grouped:
        success_rate = (sub["outcome"] == "success").mean()
        score[strat] = round(success_rate, 4)

    return score


def apply_failure_penalties(weight_dict):
    """
    Apply decay to strategies with recent failures based on classified failure data.
    """
    failures = load_failure_data()
    if failures.empty:
        return weight_dict

    fail_recent = failures[failures["failure"] == True]
    counts = fail_recent["strategy"].value_counts()

    for strat, penalty_count in counts.items():
        if strat in weight_dict:
            decay = 1.0 - min(0.05 * penalty_count, 0.4)  # Max 40% decay
            weight_dict[strat] *= decay

    return weight_dict


def reinforce(weights):
    """
    Combined reinforcement logic:
    - Boost strategies with successful labels
    - Penalize strategies with recent classified failures
    - Boost anti-fragile patterns, decay fragile patterns
    """
    label_scores = score_strategies_from_labels()
    pattern_df = load_pattern_memory()
    pattern_map = pattern_df.set_index("strategy").to_dict("index")

    for strat, base_weight in weights.items():
        # 📈 Boost by success rate from self-labeling
        success_boost = 1.0
        if strat in label_scores:
            success_boost += min(0.2 * (label_scores[strat] - 0.5), 0.3)  # Max +30%

        # 🧠 Adjust using pattern intelligence
        pattern = pattern_map.get(strat, {})
        fragility = pattern.get("fragility_rate", 0.0)
        anti_bounce = pattern.get("anti_fragile_bounces", 0)

        # Decay fragile strategies
        fragility_decay = 1.0 - min(0.4 * fragility, 0.3)  # Max -30%

        # Boost anti-fragile ones
        anti_boost = 1.0 + min(0.03 * anti_bounce, 0.2)  # Max +20%

        # Final adjustment
        weights[strat] = base_weight * success_boost * fragility_decay * anti_boost

    # Apply additional failure penalties
    weights = apply_failure_penalties(weights)

    # Normalize
    total = sum(weights.values())
    if total > 0:
        weights = {k: v / total for k, v in weights.items()}

    return weights
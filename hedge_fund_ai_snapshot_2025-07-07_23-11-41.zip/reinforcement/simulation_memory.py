import pandas as pd
import os
from datetime import datetime

def run():
    print("\n🧠 Simulation & Memory Engine Running...")

    signal_path = "logs/final_signals.csv"
    backtest_path = "logs/backtest_results.csv"
    memory_path = "logs/simulation_memory.csv"

    if not os.path.exists(signal_path) or not os.path.exists(backtest_path):
        print("❌ Missing signal or backtest log.")
        return

    signals = pd.read_csv(signal_path)
    results = pd.read_csv(backtest_path)

    # Merge to trace signal behavior and outcome
    merged = pd.merge(signals, results, on=["Date", "Asset", "Strategy"], how="inner")

    # Resolve signal column naming conflict
    if "Signal_x" in merged.columns:
        merged["Signal"] = merged["Signal_x"]
    elif "Signal" not in merged.columns:
        print("❌ 'Signal' column missing.")
        print("Columns:", list(merged.columns))
        return

    # Add success flag
    merged["Success"] = (merged["Correct"] == "✅") & (merged["Return (%)"] > 0)

    # Select memory fields
    memory_fields = [
        "Date", "Asset", "Strategy", "Signal", "Confidence",
        "Return (%)", "Correct", "Success"
    ]
    memory = merged[memory_fields].copy()

    # Append to long-term memory
    if os.path.exists(memory_path):
        existing = pd.read_csv(memory_path)
        memory = pd.concat([existing, memory]).drop_duplicates()

    memory.to_csv(memory_path, index=False)
    print(f"✅ Simulation memory updated. Total entries: {len(memory)}")

if __name__ == "__main__":
    run()

import pandas as pd
from datetime import datetime
from pathlib import Path
from reinforcement.self_label_agent import score_strategies_from_labels
from reinforcement.failure_classifier import load_failure_data
from reinforcement.deep_alpha_agent import train_alpha_agent
from risk_control.risk_budget_ai import calculate_risk_budget

WEIGHT_PATH = Path("memory/reinforced_weights.csv")
OPTIMIZED_PATH = Path("memory/optimized_weights.csv")
ALPHA_PATH = Path("memory/deep_alpha_weights.csv")

def load_base_weights():
    if OPTIMIZED_PATH.exists():
        df = pd.read_csv(OPTIMIZED_PATH)
        return dict(zip(df["strategy"], df["weight"]))
    return {}

def load_alpha_scores():
    if ALPHA_PATH.exists():
        df = pd.read_csv(ALPHA_PATH)
        return dict(zip(df["strategy"], df["alpha_score"]))
    return {}

def apply_failure_penalties(weights):
    failures = load_failure_data()
    if failures.empty:
        return weights

    fail_recent = failures[failures["failure"] == True]
    counts = fail_recent["strategy"].value_counts()

    for strat, penalty_count in counts.items():
        if strat in weights:
            decay = 1.0 - min(0.05 * penalty_count, 0.4)
            weights[strat] *= decay

    return weights

def reinforce_with_labels(weights):
    scores = score_strategies_from_labels()
    for strat, boost in scores.items():
        if strat in weights:
            weights[strat] *= 1.0 + min((boost - 0.5) * 0.4, 0.3)
    return weights

def reinforce_with_alpha(weights):
    alpha = load_alpha_scores()
    for strat in weights:
        alpha_boost = alpha.get(strat, 1.0)
        weights[strat] *= (1 + min(alpha_boost, 1.0))
    return weights

def normalize(weights):
    total = sum(weights.values())
    if total > 0:
        return {k: round(v / total, 4) for k, v in weights.items()}
    return weights

def save_weights(weights, path=WEIGHT_PATH):
    df = pd.DataFrame(list(weights.items()), columns=["strategy", "weight"])
    df.to_csv(path, index=False)
    print(f"✅ Weights saved to {path}")

def load_allocation_snapshot():
    if WEIGHT_PATH.exists():
        return pd.read_csv(WEIGHT_PATH)
    return pd.DataFrame(columns=["strategy", "weight"])

def run_full_allocator(perf_df=None):
    print("⚙️ Running Full Allocator Engine...")
    base_weights = load_base_weights()
    if not base_weights:
        print("⚠️ No base weights available.")
        return

    weights = reinforce_with_labels(base_weights)
    weights = apply_failure_penalties(weights)
    weights = reinforce_with_alpha(weights)

    if perf_df is not None:
        weights = calculate_risk_budget(weights, perf_df)

    weights = normalize(weights)
    save_weights(weights)
    return weights
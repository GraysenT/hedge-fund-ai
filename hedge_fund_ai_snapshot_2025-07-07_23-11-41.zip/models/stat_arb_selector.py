import yfinance as yf
import pandas as pd
import numpy as np
from scipy.stats import zscore
from statsmodels.tsa.stattools import coint

def get_price_data(tickers, start="2023-01-01"):
    df = yf.download(tickers, start=start)["Adj Close"]
    return df.dropna()

def find_cointegrated_pairs(price_df, threshold=0.05):
    pairs = []
    tickers = price_df.columns
    for i in range(len(tickers)):
        for j in range(i + 1, len(tickers)):
            s1 = price_df[tickers[i]]
            s2 = price_df[tickers[j]]
            _, pval, _ = coint(s1, s2)
            if pval < threshold:
                pairs.append((tickers[i], tickers[j], pval))
    return pairs

def calculate_spread_zscore(s1, s2):
    spread = s1 - s2
    z = zscore(spread)
    return z, spread
    
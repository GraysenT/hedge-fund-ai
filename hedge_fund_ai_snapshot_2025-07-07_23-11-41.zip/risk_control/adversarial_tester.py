import os
import json
import pandas as pd

PERF_PATH = "memory/performance"
AGENTS_PATH = "agents/agent_registry.json"

with open(AGENTS_PATH) as f:
    agents = json.load(f)

# Load past 10 days
files = sorted(os.listdir(PERF_PATH))[-10:]
returns = []
for file in files:
    with open(os.path.join(PERF_PATH, file)) as f:
        returns.append(json.load(f))

# Aggregate agent returns
agent_drawdowns = {}

for agent, strategies in agents.items():
    daily = []
    for r in returns:
        total = sum(r.get(s, {}).get("return_pct", 0) for s in strategies if s in r)
        daily.append(total)
    pnl_series = pd.Series(daily)
    dd = pnl_series.cumsum().min()
    agent_drawdowns[agent] = round(dd, 4)

print("\n🧪 Adversarial Stress Test (Worst Cumulative Return in 10 Days):\n")
for agent, dd in agent_drawdowns.items():
    alert = "❌ FAIL" if dd < -0.05 else "✅ PASS"
    print(f"{agent}: {dd:.4f} → {alert}")
    
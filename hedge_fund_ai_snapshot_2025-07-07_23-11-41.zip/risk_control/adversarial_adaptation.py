import pandas as pd
import os

def run(drawdown_threshold=-3.0, recent_days=5):
    print("\n⚔️ Adversarial Adaptation Engine Running...")

    path = "logs/simulation_memory.csv"
    output = "logs/adaptation_flags.csv"

    if not os.path.exists(path):
        print("❌ Simulation memory not found.")
        return

    df = pd.read_csv(path)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df["Return (%)"] = pd.to_numeric(df["Return (%)"], errors="coerce")
    df.dropna(subset=["Date", "Return (%)"], inplace=True)

    # Analyze recent data only
    recent_cutoff = df["Date"].max() - pd.Timedelta(days=recent_days)
    recent_df = df[df["Date"] >= recent_cutoff]

    # Flag breakdowns
    flagged = recent_df[recent_df["Return (%)"] <= drawdown_threshold]
    summary = flagged.groupby("Strategy").size().reset_index(name="Breakdown Count")

    summary["Adaptation Action"] = "⚠️ Reduce Trust"
    summary.to_csv(output, index=False)

    if not summary.empty:
        print("🛡️ Detected breakdowns in the following strategies:")
        print(summary)
    else:
        print("✅ No adversarial breakdowns detected.")

    print(f"📘 Adaptation log saved to: {output}")

if __name__ == "__main__":
    run()

import pandas as pd
from pathlib import Path

PERF_LOG = Path("performance_logs")
DEFENSE_LOG = Path("memory/alpha_defense_status.csv")

def load_performance():
    files = list(PERF_LOG.glob("performance_*.csv"))
    if not files:
        return pd.DataFrame()
    df = pd.concat([pd.read_csv(f) for f in files])
    df["date"] = pd.to_datetime(df["date"])
    return df

def detect_alpha_decay(perf_df, threshold=-0.02, min_days=5):
    recent = perf_df.groupby("strategy").tail(min_days)
    decay = recent.groupby("strategy")["pnl"].mean()
    decay_strats = decay[decay < threshold].index.tolist()

    df = pd.DataFrame({
        "strategy": decay.index,
        "avg_pnl": decay.values,
        "status": ["muted" if s in decay_strats else "active" for s in decay.index]
    })
    df.to_csv(DEFENSE_LOG, index=False)
    print(f"🛡️ Alpha defense log saved: {DEFENSE_LOG}")
    return decay_strats
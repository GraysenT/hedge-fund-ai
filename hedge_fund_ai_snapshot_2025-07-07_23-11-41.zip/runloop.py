import time
from datetime import datetime

from global_hours import get_market_status
from evolve import evolve_once
from ai.autonomous_upgrader import run_autonomous_upgrade_cycle
from strategies.stat_arb_engine import generate_stat_arb_signals
from execution.stat_arb_executor import execute_stat_arb_signals
from risk_control.hedging_engine import (
    estimate_sector_exposure,
    generate_hedge_orders,
    log_hedge_actions,
)
from dashboards.market_display import update_market_status_display  # Optional real-time dashboard
from execution.account_logger import log_account_trade
from execution.signal_executor import execute_signal  # assuming you have this

# example of account_signal_dict:
# {
#   "main_fund": [df of stat arb signals],
#   "hedge_fund_alpha": [df of volatility signals],
#   ...
# }

for account_id, signal_df in account_signal_dict.items():
    for _, signal in signal_df.iterrows():
        # Optional: Execute the signal
        execute_signal(signal)

        # Log the trade for the correct account
        trade_data = signal.to_dict()
        log_account_trade(account_id, trade_data)

from performance.performance_logger import log_strategy_performance

log_strategy_performance({
    "stat_arb": {"pnl": 132, "capital_used": 1800},
    "volatility_spike": {"pnl": -60, "capital_used": 1000},
    "ml_macro": {"pnl": 215, "capital_used": 2500}
})

def run():
    while True:
        print(f"\n🕒 Runloop cycle started @ {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}")

        # 🧠 Check global market status
        market_status = get_market_status()
        if market_status.get("US Stocks") == "Closed" and market_status.get("Futures") == "Closed":
            print("⏸️ Markets are closed. Skipping cycle.")
            time.sleep(60)
            continue

        # ✅ 1. Evolve strategies
        evolve_once()

        # ✅ 2. Run statistical arbitrage engine
        stat_arb_signals = generate_stat_arb_signals()
        if not stat_arb_signals.empty:
            execute_stat_arb_signals(stat_arb_signals)

        # ✅ 3. Apply smart hedging logic
        exposure_map = estimate_sector_exposure(stat_arb_signals)
        hedge_orders = generate_hedge_orders(exposure_map)
        log_hedge_actions(hedge_orders)

        # ✅ 4. Run autonomous upgrade engine
        run_autonomous_upgrade_cycle()

        # ⏱ Sleep before next round
        time.sleep(1800)  # 30 minutes
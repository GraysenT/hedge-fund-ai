import streamlit as st
import pandas as pd
import os
from datetime import datetime

st.set_page_config(page_title="Phase 5: Evolution Engine", layout="wide")
st.title("🧠 Phase 5 – Evolution Intelligence Monitor")

def load_csv(path):
    return pd.read_csv(path) if os.path.exists(path) else None

# === Self-Labeled Patterns ===
st.subheader("📘 Self-Labeled Patterns")
label_df = load_csv("logs/self_labeled_patterns.csv")
if label_df is not None and not label_df.empty:
    st.dataframe(label_df)
else:
    st.info("ℹ️ No labeled patterns yet.")

# === Meta Feedback Scores ===
st.divider()
st.subheader("📈 Meta Feedback Scores")
meta_df = load_csv("logs/meta_feedback_scores.csv")
if meta_df is not None and not meta_df.empty:
    st.dataframe(meta_df.round(3))
    st.bar_chart(meta_df.set_index("Strategy")["Meta Score"])
else:
    st.info("ℹ️ No meta feedback available.")

# === Simulation Memory ===
st.divider()
st.subheader("🧪 Simulation Memory Summary")
mem_df = load_csv("logs/simulation_memory.csv")
if mem_df is not None and not mem_df.empty:
    st.write(f"🧠 Total Memory Entries: {len(mem_df)}")
    st.dataframe(mem_df.tail(10))
else:
    st.info("ℹ️ No memory log yet.")

# === Alpha Defense Status ===
st.divider()
st.subheader("🛡️ Alpha Health Report")
alpha_df = load_csv("logs/alpha_defense_report.csv")
if alpha_df is not None and not alpha_df.empty:
    st.dataframe(alpha_df)
else:
    st.info("ℹ️ No alpha health report found.")

# === Adversarial Adaptation ===
st.divider()
st.subheader("⚔️ Adversarial Adaptation Flags")
adapt_df = load_csv("logs/adaptation_flags.csv")
if adapt_df is not None and not adapt_df.empty:
    st.dataframe(adapt_df)
else:
    st.info("ℹ️ No adversarial adaptation flags detected.")

# Timestamp
st.caption(f"Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")

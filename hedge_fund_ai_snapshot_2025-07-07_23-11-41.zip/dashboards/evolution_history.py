import os
import json
import pandas as pd
import streamlit as st

LOG_DIR = "strategy_memory/evolution_logs"

st.set_page_config(page_title="📜 Evolution History", layout="wide")
st.title("📜 Strategy Evolution Log Viewer")

files = sorted([f for f in os.listdir(LOG_DIR) if f.endswith(".json")], reverse=True)

if not files:
    st.warning("No evolution logs found.")
    st.stop()

selected = st.selectbox("Select a log to view", files)
with open(os.path.join(LOG_DIR, selected), 'r') as f:
    data = json.load(f)

st.markdown(f"### 🕒 Timestamp: `{data['timestamp']}`")

col1, col2 = st.columns(2)

with col1:
    st.subheader("🔇 Muted Strategies")
    st.write(data.get("muted_strategies", []))

with col2:
    st.subheader("🚀 Promoted Strategies")
    st.write(data.get("promoted_strategies", []))

# Summary table
st.subheader("📊 Strategy Score Summary")
df = pd.DataFrame(data.get("summary", []))
st.dataframe(df.sort_values(by="Avg Sharpe", ascending=False), use_container_width=True)

# Export
st.download_button(
    label="📥 Download Log JSON",
    data=json.dumps(data, indent=2),
    file_name=selected,
    mime="application/json"
)

import streamlit as st
import pandas as pd
import os
from datetime import datetime

st.set_page_config(page_title="AI Research & Deployment", layout="wide")
st.title("📘 AI Research & Deployment Dashboard")

def load_csv(path):
    return pd.read_csv(path) if os.path.exists(path) else None

# === Section: Research Memory ===
st.subheader("🧠 Research Memory (Hypothesis Log)")
memory = load_csv("logs/research_memory.csv")
if memory is not None and not memory.empty:
    st.dataframe(memory.sort_values("Occurrences", ascending=False).reset_index(drop=True))
    st.caption(f"Total hypotheses stored: {len(memory)}")
else:
    st.info("ℹ️ No hypotheses stored yet.")

# === Section: Simulation Results ===
st.divider()
st.subheader("🔬 Simulation Results (Autonomous Agent)")
sim = load_csv("logs/research_simulations.csv")
if sim is not None and not sim.empty:
    st.dataframe(sim.sort_values("Simulated Return (%)", ascending=False).reset_index(drop=True))
    st.caption(f"Total simulations: {len(sim)}")
else:
    st.info("ℹ️ No simulations have been run yet.")

# === Section: Feedback Scores ===
st.divider()
st.subheader("📈 Research Feedback Scores")
scores = load_csv("logs/research_feedback_scores.csv")
if scores is not None and not scores.empty:
    st.dataframe(scores.sort_values("Research Boost Score", ascending=False).reset_index(drop=True))
else:
    st.info("ℹ️ No research scores available yet.")

# === Optional Future Controls ===
st.divider()
st.subheader("🟢 Idea Deployment (Coming Soon)")
st.write("In future versions, you'll be able to promote top-performing hypotheses into live strategies or simulations from here.")

# === Timestamp ===
st.caption(f"Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")

# === Section: Promoted Ideas ===
st.divider()
st.subheader("🟢 Promoted Ideas")

promos = load_csv("logs/promoted_ideas.csv")
if promos is not None and not promos.empty:
    st.dataframe(promos.sort_values("Simulated Return (%)", ascending=False).reset_index(drop=True))
    st.caption(f"Total promoted ideas: {len(promos)}")
else:
    st.info("ℹ️ No promoted ideas found yet.")

# === Section: Recursive Lineage (From → To)
st.divider()
st.subheader("🌱 Recursive Logic Growth")

hypo = load_csv("logs/generated_hypotheses.csv")
if hypo is not None and "Generated From" in hypo.columns:
    lineage = hypo[["Hypothesis ID", "Generated From", "Strategy", "Confidence Range"]].dropna()
    if not lineage.empty:
        st.dataframe(lineage.sort_values("Generated From"))
        st.caption("🧠 Showing hypotheses recursively generated from promoted parents.")
    else:
        st.info("ℹ️ No recursive ideas yet.")
else:
    st.info("ℹ️ No hypothesis lineage available.")

# === Section: Deployability Status ===
st.divider()
st.subheader("📊 Deployability Status")

deploy = load_csv("logs/deployability_scores.csv")
if deploy is not None and not deploy.empty:
    status_filter = st.selectbox("Filter by Status", ["All", "✅ Deployable", "🧪 Experimental", "⛔ Unqualified"])
    if status_filter != "All":
        deploy = deploy[deploy["Status"] == status_filter]

    st.dataframe(deploy.sort_values("Deployability Score", ascending=False).reset_index(drop=True))
    st.caption(f"Total ideas scored: {len(deploy)}")
else:
    st.info("ℹ️ No deployability scores found yet.")

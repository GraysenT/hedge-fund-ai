import streamlit as st
from control.override_manager import load_overrides, set_override

st.set_page_config(layout="wide")
st.title("🧠 Global Control Center")

overrides = load_overrides()

st.subheader("Override Flags")
for key in ["mute_all_stat_arb", "pause_trading", "global_debug_mode"]:
    current = overrides.get(key, False)
    new_val = st.checkbox(key, value=current)
    if new_val != current:
        set_override(key, new_val)

st.success("⚙️ Overrides updated.")
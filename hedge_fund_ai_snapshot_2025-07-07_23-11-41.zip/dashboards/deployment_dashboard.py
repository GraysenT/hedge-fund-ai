import streamlit as st
import pandas as pd
import os
from datetime import datetime

st.set_page_config(page_title="Deployment & Oversight", layout="wide")
st.title("📊 Strategy Deployment & Oversight Dashboard")

def load_csv(path):
    return pd.read_csv(path) if os.path.exists(path) else None

# === Section: Deployability Scores
st.subheader("📘 Deployability Status")
scores = load_csv("logs/deployability_scores.csv")
if scores is not None and not scores.empty:
    status_filter = st.selectbox("Filter by Status", ["All", "✅ Deployable", "🧪 Experimental", "⛔ Unqualified"])
    if status_filter != "All":
        scores = scores[scores["Status"] == status_filter]

    st.dataframe(scores[["Hypothesis ID", "Strategy", "Simulated Return (%)", "Deployability Score", "Status"]])
    st.caption(f"Last scored: {scores['Scored At'].max()}")
else:
    st.info("ℹ️ No deployability scores found.")

# === Section: Routing Plans
st.divider()
st.subheader("📦 Routing Plans")

col1, col2 = st.columns(2)

live = load_csv("logs/live_routing.csv")
paper = load_csv("logs/paper_routing.csv")

with col1:
    st.markdown("✅ **Live Routing**")
    if live is not None and not live.empty:
        st.dataframe(live)
    else:
        st.warning("No live strategies routed.")

with col2:
    st.markdown("🧪 **Paper Routing**")
    if paper is not None and not paper.empty:
        st.dataframe(paper)
    else:
        st.warning("No paper strategies routed.")

# === Section: Muted Strategies
st.divider()
st.subheader("🔕 Muted Strategies")
if scores is not None and not scores.empty:
    muted = scores[scores["Status"] == "⛔ Unqualified"]
    if not muted.empty:
        st.dataframe(muted[["Strategy", "Simulated Return (%)", "Deployability Score"]])
    else:
        st.success("All strategies are currently qualified.")
else:
    st.info("ℹ️ No muted strategies to display.")

st.caption(f"Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")

# === Section: Confidence vs. Risk Overview ===
st.divider()
st.subheader("📈 Confidence vs. Risk")

risk_df = load_csv("logs/confidence_risk_scores.csv")
if risk_df is not None and not risk_df.empty:
    st.dataframe(risk_df[["Strategy", "Avg Confidence", "Estimated Risk", "Confidence/Risk Ratio"]])

    # Chart: Confidence vs Risk
    st.markdown("### 🔍 Visual: Confidence vs Risk")
    st.bar_chart(risk_df.set_index("Strategy")[["Avg Confidence", "Estimated Risk"]])

    # Highlight outliers
    outliers = risk_df[risk_df["Confidence/Risk Ratio"] < 1.0]
    if not outliers.empty:
        st.warning("⚠️ These strategies have risk exceeding confidence:")
        st.dataframe(outliers[["Strategy", "Avg Confidence", "Estimated Risk", "Confidence/Risk Ratio"]])
    else:
        st.success("✅ All strategies have confidence greater than risk.")
else:
    st.info("ℹ️ No confidence vs. risk data found.")

# === Section: Strategy Approval Votes ===
st.divider()
st.subheader("🗳️ Strategy Approval Log")

votes = load_csv("logs/strategy_approval_log.csv")
if votes is not None and not votes.empty:
    vote_filter = st.selectbox("Filter by Vote", ["All", "✅ Approved", "⚠️ Needs Review", "⛔ Rejected"])
    if vote_filter != "All":
        votes = votes[votes["Vote"] == vote_filter]
    st.dataframe(votes[["Strategy", "Status", "Confidence/Risk Ratio", "Vote"]])
    st.caption(f"Voted at: {votes['Voted At'].max()}")
else:
    st.info("ℹ️ No strategy votes found.")

import json
import os
import pandas as pd
from datetime import datetime

print("\n📊 Capital Allocation Scaling Table:")

# Load latest scaled allocations
alloc_dir = "memory/scaled_allocations"
if os.path.exists(alloc_dir):
    latest_file = sorted(os.listdir(alloc_dir))[-1]
    alloc_path = os.path.join(alloc_dir, latest_file)
    with open(alloc_path, "r") as f:
        scaled_allocs = json.load(f)
else:
    print("⚠️ No capital allocations found.")
    scaled_allocs = {}

# Load strategy lineage
with open("strategy_memory/strategy_lineage.json") as f:
    lineage = json.load(f)

# Load deployment status
deployment_path = "strategy_memory/deployment_status.json"
deployment_status = {}
if os.path.exists(deployment_path):
    with open(deployment_path) as f:
        deployment_status = json.load(f)

# Build table
records = []
for strat, weight in scaled_allocs.items():
    lineage_info = lineage.get(strat, {})
    deployed = deployment_status.get(strat, {}).get("approved", False)
    records.append({
        "Strategy": strat,
        "Sharpe": lineage_info.get("sharpe", 0),
        "Depth": lineage_info.get("depth", 0),
        "Approved": "✅" if deployed else "❌",
        "Capital Weight": weight
    })

df = pd.DataFrame(records).sort_values(by="Capital Weight", ascending=False)
print(df.to_string(index=False))

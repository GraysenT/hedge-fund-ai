from datetime import datetime
from portfolio_ai.full_allocator import allocate_capital
from reinforcement.self_label_agent import reinforce
from evolution.snapshot_saver import save_evolution_snapshot
from reinforcement.failure_classifier import classify_failures
from reinforcement.pattern_memory import update_pattern_memory
from ai.autonomous_upgrader import run_autonomous_upgrade_cycle
from performance.performance_tracker import log_daily_performance

# Simulated placeholder inputs
def get_live_strategy_scores():
    return {
        "strategy_ema_fast": 0.3,
        "strategy_ema_slow": 0.3,
        "strategy_news_sentiment": 0.2,
        "strategy_lstm": 0.2
    }

def get_daily_pnl_by_strategy():
    return {
        "strategy_ema_fast": 120.5,
        "strategy_ema_slow": -45.2,
        "strategy_news_sentiment": -80.1,
        "strategy_lstm": 92.3
    }

def get_capital_usage_by_strategy():
    return {
        "strategy_ema_fast": 1000,
        "strategy_ema_slow": 1000,
        "strategy_news_sentiment": 800,
        "strategy_lstm": 1000
    }

def get_sharpe_by_strategy():
    return {
        "strategy_ema_fast": 1.8,
        "strategy_ema_slow": 0.6,
        "strategy_news_sentiment": -0.3,
        "strategy_lstm": 1.5
    }

def evolve():
    print("\n🔁 Evolution Cycle Started:", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))

    # 1. Load current strategy scores
    raw_weights = get_live_strategy_scores()

    # 2. Apply reinforcement
    reinforced_weights = reinforce(raw_weights)

    # 3. Allocate capital based on final weights
    allocate_capital(reinforced_weights)

    # 4. Classify failures and update pattern memory
    classify_failures()
    update_pattern_memory()

    # 5. Log performance snapshot
    today = datetime.utcnow().strftime("%Y-%m-%d")
    log_daily_performance(
        date=today,
        pnl_dict=get_daily_pnl_by_strategy(),
        capital_dict=get_capital_usage_by_strategy(),
        sharpe_dict=get_sharpe_by_strategy()
    )

    # 6. Save full snapshot
    save_evolution_snapshot()

    # 7. Run autonomous upgrade agent (NEW)
    run_autonomous_upgrade_cycle()

    print("✅ Evolution Cycle Complete\n")


if __name__ == "__main__":
    evolve()
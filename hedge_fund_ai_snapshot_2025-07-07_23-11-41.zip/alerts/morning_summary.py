def send_morning_email():
    print("📬 [LOG-ONLY MODE] Morning Forecast Email Content:")
    print("-----------------------------------------------")
    print("Subject: 📈 Morning Forecast Summary")
    print("Body:\n")
    print("Good morning!\n")
    print("Here are your latest AI-generated commodity forecasts.\n")
    print("Check your dashboard or logs for detailed trades.\n")
    print("📬 Sent automatically by your hedge fund AI system.\n")
